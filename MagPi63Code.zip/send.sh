#!/usr/bin/env bash

PASSWORD=MemberPasswordl

HOST='ftp.growlode.com'
USER='member@members.growlode.com'
FILE='lastsnap.jpg'

cd /var/lib/motion
ftp -n $HOST <<END_SCRIPT
quote USER $USER
quote PASS $PASSWORD
binary
put $FILE
quit
END_SCRIPT
exit 0
